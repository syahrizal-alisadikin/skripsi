<?php $__env->startSection('content'); ?>
    <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Dashboard</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Update Mahasiswa</li>
                        </ol>
                       <?php if(session('create')): ?>
                        <div class="alert alert-primary">
                            <?php echo e(session('create')); ?>

                
                        </div>
                        <?php endif; ?>
                                
                        <div class="container">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="card">
                                        <div class="card-body">
                                            <h4 class="text-center">Update Mahasiswa</h4>
                                        <form action="<?php echo e(route('tu-mahasiswa.update',$data->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                 <div class="form-group">
                                                    <label for="nim">Nim</label>
                                                    <input type="text" name="nim" id="nim" class="form-control" value="<?php echo e($data->nim); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label for="name">Nama</label>
                                                    <input type="text" name="name" id="name" class="form-control" value="<?php echo e($data->name); ?>">
                                                </div>

                                                 <div class="form-group">
                                                    <label for="semester">Semester</label>
                                                    <select name="semester" id="semester" class="form-control">
                                                    <option value="<?php echo e($data->id_semester); ?>"><?php echo e($data->semester->name); ?></option>
                                                    <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                                        
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                 <div class="form-group">
                                                    <label for="jurusan">Jurusan</label>
                                                    <select name="jurusan" id="jurusan" class="form-control">
                                                    <option value="<?php echo e($data->id_jurusan); ?>"><?php echo e($data->jurusan->name); ?></option>
                                                    <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($jurus->id); ?>"><?php echo e($jurus->name); ?></option>
                                                        
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                
                                                 <div class="form-group">
                                                    <label for="email">Email</label>
                                                    <input type="email" name="email" id="email" class="form-control" value="<?php echo e($data->email); ?>">
                                                </div>
                                                 <div class="form-group">
                                                    <label for="password">Password</label>
                                                    <input type="password" name="password" id="password" class="form-control" >
                                                </div>

                                                <div class="form-group">
                                                    <label for="alamat">Alamat</label>
                                                    <input type="alamat" name="alamat" id="alamat" class="form-control" value="<?php echo e($data->alamat); ?>">
                                                </div>
                                                
                                                

                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-success d-block w-100"> Update Data</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('tu.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\skripsi\resources\views/tu/mahasiswa/update.blade.php ENDPATH**/ ?>