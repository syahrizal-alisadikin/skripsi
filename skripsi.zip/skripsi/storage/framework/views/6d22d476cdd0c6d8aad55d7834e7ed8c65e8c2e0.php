<?php $__env->startSection('content'); ?>

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Jadwal Dosen <?php echo e(Auth::guard('dosen')->user()->name); ?></li>
        </ol>
        <?php if(session('create')): ?>
        <div class="alert alert-primary">
            <?php echo e(session('create')); ?>


        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header d-flex">
                        <div class="data">
                            <i class="fas fa-table mr-1"></i>
                            <?php echo e($jadwal->name); ?>

                        </div>

                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            
                            <?php if($message = Session::get('sukses')): ?>
                            <div class="alert alert-success alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button> 
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php endif; ?>

                            <?php if($message = Session::get('gagal')): ?>
                            <div class="alert alert-danger alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button> 
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php endif; ?>

                            <?php if($message = Session::get('peringatan')): ?>
                            <div class="alert alert-warning alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button> 
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php endif; ?>

                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>File Materi</th>
                                        <th>Nama Materi</th>
                                        <th class="text-center">Materi </th>

                                    </tr>
                                </thead>

                                <tbody>
                                    
                                    <?php $__empty_1 = true; $__currentLoopData = $materi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><iframe src="<?php echo e(url('/dosen/upload/' . $item->materi)); ?>"></iframe></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td>
                                            <span class="badge badge-primary">File PDF Saja</span>
                                        </td>
                                    </tr>
                                    

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center">Belum Ada Materi <br>
                                         
                                           <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#uploadFile">
                                              Upload File
                                          </button>
                                       </td>
                                   </tr>
                                   <?php endif; ?>
                               </tbody>
                           </table>
                       </div>
                   </div>
               </div>
           </div>
           <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <?php if($message = Session::get('sukses_absen')): ?>
                    <div class="alert alert-success alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>

                    <?php if($message = Session::get('gagal_absen')): ?>
                    <div class="alert alert-danger alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>

                    <?php if($message = Session::get('peringatan_absen')): ?>
                    <div class="alert alert-warning alert-block">
                        <button type="button" class="close" data-dismiss="alert">×</button> 
                        <strong><?php echo e($message); ?></strong>
                    </div>
                    <?php endif; ?>
                   <?php
                       $absen = App\Absen::where('id_jadwal', $jadwal->id)->where('id_dosen',Auth::guard('dosen')->user()->id)->get();
                       
                   ?>
                   <?php $__currentLoopData = $absen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php
                           $kerja = $item->jam_keluar;
                       ?> 
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php if($kerja == $kerja): ?>
                   <form action="<?php echo e(route('update.absen',$data_absen->id)); ?>" method="POST">
                     <?php if($message = Session::get('success')): ?>
                            <div class="alert alert-success alert-block">
                                <button type="button" class="close" data-dismiss="alert">×</button> 
                                <strong><?php echo e($message); ?></strong>
                            </div>
                            <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("PUT"); ?>
                        <div class="form-group">
                            <input type="text" id="matkul" class="form-control" value="<?php echo e($jadwal->matkul->nama); ?>">
                            <input type="hidden" name="id_jadwal" id="id_jadwal" class="form-control" value="<?php echo e($jadwal->id); ?>">
                        </div>
                        
                        <div class="form-group">
                            <input type="text" id="matkul" class="form-control" value="Mata kuliah Selesai">
                            <input type="hidden" name="id_jadwal" id="id_jadwal" class="form-control" value="<?php echo e($jadwal->id); ?>">
                        </div>
                        <div>
                            <button type="submit" class="btn btn-success d-block w-100">Absen keluar</button>
                        </div>
                    </form>
                   <?php else: ?>
                    <form action="<?php echo e(route('process.absen')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input type="text" id="matkul" class="form-control" value="<?php echo e($jadwal->name); ?>">
                            <input type="hidden" name="id_jadwal" id="id_jadwal" class="form-control" value="<?php echo e($jadwal->id); ?>">
                        </div>
                        <div class="form-group">
                            <select name="keterangan" id="keterangan" class="form-control">
                                <option value="hadir">Hadir</option>
                                <option value="izin">Izin</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <textarea name="alesan" id="alesan" class="form-control" cols="30" rows="3" placeholder="keterangan"></textarea>
                            <small style="color: red;">* Kosongkan Jika Hadir</small>
                        </div>
                        <div>
                            <button type="submit" class="btn btn-success d-block w-100">Kirim</button>
                        </div>
                    </form>
                    <?php endif; ?>
                   
                    
                </div>
            </div>
        </div>
    </div>
</div>
</main>

<div>
    
</div>

<!-- Modal -->


<div class="modal fade" id="uploadFile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Upload Materi</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
      </button>
  </div>
  <div class="modal-body">
      <form action="<?php echo e(route('upload.materi')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Nama Materi</label>
            <input type="text" name="name_materi" class="form-control" placeholder="Nama Materi" required>
            <input type="hidden" class="btn btn-primary" name="id_jadwal" value="<?php echo e($jadwal->id); ?>">
        </div>
        <div class="form-group">
            <label>File Materi</label>
            <input type="file" name="materi" class="form-control"required>
            <small style="color: red">* khusus File PDF</small>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary d-block w-100">Upload Materi</button>

        </div>
    </form>
</div>

</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dosen.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\skripsi\resources\views/dosen/absen-kelas.blade.php ENDPATH**/ ?>