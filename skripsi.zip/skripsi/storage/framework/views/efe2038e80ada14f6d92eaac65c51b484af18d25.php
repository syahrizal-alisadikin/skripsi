<?php $__env->startSection('content'); ?>
    <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Dashboard</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Update MataKuliah</li>
                        </ol>
                       <?php if(session('create')): ?>
                        <div class="alert alert-primary">
                            <?php echo e(session('create')); ?>

                
                        </div>
                        <?php endif; ?>
                                
                        <div class="container">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="card">
                                        <div class="card-body">
                                            <h4 class="text-center">Update MataKuliah</h4>
                                        <form action="<?php echo e(route('namamatkul.update',$data->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="form-group">
                                                    <label for="name">Kode</label>
                                                    <input type="text" name="kode" id="kode" class="form-control" value="<?php echo e($data->kode); ?>">
                                                </div>
                                                <div class="form-group">
                                                    <label for="name">Nama Matakuliah</label>
                                                    <input type="text" name="name" id="name" class="form-control" value="<?php echo e($data->nama); ?>">
                                                </div>

                                                 <div class="form-group">
                                                    <label for="name">Sks</label>
                                                    <input type="text" name="sks" id="sks" class="form-control" value="<?php echo e($data->sks); ?>">
                                                </div>
                                                
                                                 
                                                
                                                
                                                

                                                <div class="form-group">
                                                    <button type="submit" class="btn btn-success d-block w-100"> Update Data</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('tu.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\skripsi\resources\views/tu/namamatkul/update.blade.php ENDPATH**/ ?>