<?php $__env->startSection('content'); ?>
<main>
  <div class="container-fluid">
    <h1 class="mt-4">Detail Absen Dosen</h1>
    <ol class="breadcrumb mb-4">
      <li class="breadcrumb-item active">Detail Absen Dosen <?php echo e($dosen->name); ?></li>
    </ol>
    <?php if(session('create')): ?>
    <div class="alert alert-primary">
      <?php echo e(session('create')); ?>

    </div>
    <?php endif; ?>
    <div class="card">
      <div class="card-header d-flex">
        <div class="data">
          Print Data Bulan Dan Harian
        </div>
      </div>
      <div class="card-body">
          <div class="col-lg-12">
            <div class="row">
              <div class="col-lg-6">
                <div class="data">
                  Print PDF 1 Bulan
                </div><br>
                <form method="GET" action="<?php echo e(url('/admin/absen-dosen/detail/cetak/' . $dosen->id)); ?>">
                  <div class="form-group">
                    <div class="ml-auto">
                      <input class="form-control" type="date" name="tanggal_start" value="<?php echo e(date('Y-m-d')); ?>">
                    </div>
                  </div>
                  <div class="form-group">                
                    <div class="ml-auto">
                      <input class="form-control" type="date" name="tanggal_end">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="button">        
                      <button class="btn btn-danger btn-sm">Print PDF</button>
                    </div> 
                  </div> 
                </form>
              </div>
              <div class="col-lg-6">
                <div class="data">
                  Print PDF Per Hari
                </div><br>
                <form method="GET" action="<?php echo e(url('admin/absen-dosen/detail/cetak-perhari/' . $dosen->id)); ?>">
                  <div class="form-group">
                    <input class="form-control" type="date" name="tanggal_start" value="<?php echo e(date('Y-m-d')); ?>">
                  </div>
                  <button class="btn btn-danger btn-sm" type="submit">Print PDF</button>
                </form> 
              </div>
            </div>
          </div>
        </div>
    </div>
    <br><br>
    <div class="card mb-4">
      <div class="card-header d-flex">
       <div class="data">
        <i class="fas fa-table mr-1"></i>
        Abseni Dosen <?php echo e($dosen->name); ?>

      </div>
    </div>
    <div class="card-body">

      <!-- pengecekan jika absen dosen kosong -->
      <?php if(empty($detail_dosen->count() > 0)): ?>
      <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button> 
        <strong>Upsss!! Absen Anda Kosong</strong>
      </div>
      <?php endif; ?>

      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Dosen</th>
              <th>Nama Matkul</th>
              <th>Jenis Kelas</th>
              <th>Tanggal</th>
              <th>Keterangan Absen</th>
              <th>Alesan Absen</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $detail_dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($loop->iteration); ?></td>
              <td><?php echo e($key->nama_dosen); ?></td>
              <td><?php echo e($key->nama); ?></td>
              <td><?php echo e($key->jenis_kelas); ?></td>
              <td><?php echo e($key->tanggal); ?></td>
              <td><?php echo e($key->keterangan); ?></td>
              <td><?php echo e($key->alesan); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

        
        </div>
      </div>
    </div>
  </main>

  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('javascript'); ?>

  <!-- javascript Modal Detail  -->
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('tu.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u4474281/public_html/latihan/resources/views/tu/absen/absen_detail.blade.php ENDPATH**/ ?>