<?php $__env->startSection('content'); ?>
    <main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Dashboard</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">MataKuliah</li>
                        </ol>
                       <?php if(session('create')): ?>
                        <div class="alert alert-primary">
                            <?php echo e(session('create')); ?>

                
                        </div>
                        <?php endif; ?>
                                
                        <div class="card mb-4">
                            <div class="card-header d-flex">
                               <div class="data">
                                    <i class="fas fa-table mr-1"></i>
                                DataTable Example
                                </div>
                                <div class="button ml-auto">
                                    <a href="#" class="btn btn-success" name="tambah" id="tambah" data-toggle="modal" data-target="#exampleModal">Tambah Jadwal</a>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Matakuliah</th>
                                                <th>SKS</th>
                                                <th>Jadwal</th>
                                                <th> Mulai</th>
                                                <th> Selesai</th>
                                                <th>Pengajar</th>
                                                <th>Sesi</th>
                                                <th class="text-center">Aksi</th>
                                            </tr>
                                        </thead>
                                       
                                        <tbody>
                                        
                                          <?php $i=1 ?>
                                           <?php $__currentLoopData = $matakuliah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?= $i ?></td>
                                                <td><?php echo e($item->matkul->nama); ?></td>
                                                <td><?php echo e($item->matkul->sks); ?></td>
                                                <td><?php echo e($item->hari); ?></td>
                                                <td><?php echo e($item->jam_mulai); ?></td>
                                                <td><?php echo e($item->jam_selesai); ?></td>
                                                <td><?php echo e($item->dosen->name); ?></td>
                                                <td><?php echo e($item->jenis_kelas); ?></td>
                                                <td class="text-center">
                                                        <a href="<?php echo e(route('matakuliah.edit',$item->id)); ?>"  class="btn btn-primary btn-sm">Edit</a>
                                                        <form action="<?php echo e(route('matakuliah.destroy', $item->id)); ?>" method="POST" class="d-inline">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('delete'); ?>

                                                            <button type="submit" class="btn btn-danger btn-sm"  onclick="return confirm('Yakin Data Mau Dihapus??');"> Hapus</button>
                                                        </form>
                                                    </td>
                                            </tr>

                                          <?php $i++ ?>
                                            
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>




<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Matakuliah</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form action="<?php echo e(route('matakuliah.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <div class="form-group">
            <label for="name">Kode Matakuliah</label>
            <select class="form-control" id="name" name="name">
                <?php $__currentLoopData = $matkul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matkul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($matkul->id); ?>"><?php echo e($matkul->kode); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
       
      
        <div class="form-group">
            <label for="semester">Dosen</label>
            <select name="dosen" id="dosen" class="form-control">
                <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="semester">Semester</label>
            <select name="semester" id="semester" class="form-control">
                <?php $__currentLoopData = $semester; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
         <div class="form-group">
             <label for="jenis_kelas">Jenis Kelas</label>
             <select name="jenis_kelas" id="jenis_kelas" class="form-control">
                 <option value="pagi">Pagi</option>
                 <option value="sore">Sore</option>
             </select>
         </div>
        
        <div class="form-group">
            <label for="email">Hari</label>
            <select name="hari" id="hari" class="form-control">
                <option value="Senin">Senin</option>
                <option value="Selasa">Selasa</option>
                <option value="Rabu">Rabu</option>
                <option value="Kamis">Kamis</option>
                <option value="Jum'at">Jum'at</option>
            </select>
        </div>
         <div class="form-group">
            <label for="password">Jam Mulai</label>
            <select name="mulai" id="mulai" class="form-control">
                <option value="06.00">06.00</option>
                <option value="07.00">07.00</option>
                <option value="08.00">08.00</option>
            </select>
        </div>
          <div class="form-group">
            <label for="password">Jam Selesai</label>
            <select name="selesai" id="selesai" class="form-control">
                <option value="10.00">10.00</option>
                <option value="11.00">11.00</option>
                <option value="12.00">12.00</option>
            </select>
        </div>
         
        
      

        <div class="form-group">
        <button type="submit" class="btn btn-success d-block w-100">Tambah Data</button>

        </div>
        </form>
      </div>
      
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tu.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u4474281/public_html/latihan/resources/views/tu/matakuliah/index.blade.php ENDPATH**/ ?>