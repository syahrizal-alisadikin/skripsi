
<?php $__env->startSection('content'); ?>

<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Absen Dosen <?php echo e(Auth::guard('dosen')->user()->name); ?></li>
        </ol>
        <?php if(session('create')): ?>
        <div class="alert alert-primary">
            <?php echo e(session('create')); ?>

            
        </div>
        <?php endif; ?>
        <?php if(session('izin')): ?>
        <div class="alert alert-primary">
            <?php echo e(session('izin')); ?>

            
        </div>
        <?php endif; ?>
        
        <div class="card mb-4">
            <div class="card-header d-flex">
             <div class="data">
                <i class="fas fa-table mr-1"></i>
                Absen Dosen
            </div>
            
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Matakuliah</th>
                            <th>Kode</th>
                            <th>Sks </th>
                            <th>Hari</th>
                            <th> Mulai</th>
                            <th>Selesai</th>
                            <th>Sesi</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                        <?php $i = 1?>
                        <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?=$i?></td>
                                <td><?php echo e($item->jadwal->matkul->nama); ?></td>
                                <td><?php echo e($item->jadwal->matkul->kode); ?></td>
                                <td><?php echo e($item->jadwal->matkul->sks); ?></td>
                                <td><?php echo e($item->jadwal->hari); ?></td>
                                <td><?php echo e($item->created_at->format('H:i:s')); ?></td>
                                <td><?php echo e($item->updated_at->format('H:i:s')); ?></td>
                                <td><?php echo e($item->jadwal->jenis_kelas); ?></td>
                                <td><?php echo e($item->keterangan); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</main>






</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dosen.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\skripsi\resources\views/dosen/absen_dosen.blade.php ENDPATH**/ ?>