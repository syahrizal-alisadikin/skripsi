<?php $__env->startSection('content'); ?>

<main>
                    <div class="container-fluid">
                        <h1 class="mt-4">Dashboard</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">Data Mahasiswa</li>
                        </ol>
                       <?php if(session('create')): ?>
                        <div class="alert alert-primary">
                            <?php echo e(session('create')); ?>

                
                        </div>
                        <?php endif; ?>
                                
                        <div class="card mb-4">
                            <div class="card-header d-flex">
                               <div class="data">
                                    <i class="fas fa-table mr-1"></i>
                                Data Mahasiswa
                                </div>
                                
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Semester</th>
                                                <th>Jurusan </th>
                                                <th>Email</th>
                                            </tr>
                                        </thead>
                                       
                                        <tbody>
                                         <?php $i = 1 ?>
                                         <?php $__currentLoopData = $mahasiswas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <tr>
                                                 <td><?= $i?></td>
                                                 <td><?php echo e($item->name); ?></td>
                                                 <td><?php echo e($item->jurusan->name); ?></td>
                                                 <td><?php echo e($item->email); ?></td>
                                             </tr>
                                         <?php $i++?>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>





    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dosen.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\skripsi\resources\views/dosen/mahasiswa/index.blade.php ENDPATH**/ ?>